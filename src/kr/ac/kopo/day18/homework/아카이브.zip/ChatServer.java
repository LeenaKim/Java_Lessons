package kr.ac.kopo.day18.homework;


import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
/*
 * 서버단에서 클라이언트의 메세지를 받아서 다시 보내지말고, 
 * 소켓 형의 클라이언트를 스레드로 보내면 클라이언트가 접속할때마다 여러개의 스레드가 생겨
 * 멀티스레드의 형태로 동시 접속이 가능하다. 
 */
public class ChatServer {
	
	private HashMap<String, Socket> hm;

	public void start(int portNo) {
		
		try {
			ServerSocket server = new ServerSocket(portNo);	
			hm = new HashMap<String, Socket>();
			
			while (true) {
				Socket client = server.accept();
				ChatServerThread chatThread = new ChatServerThread (client, hm);// 파일 입출력은 스레드가 하게 넘겨준다. 
				chatThread.start();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
