package kr.ac.kopo.day18.homework;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;

public class ChatServerThread extends Thread {

	private Socket client;
	private PrintWriter pw;
	private String id;
	private String userMsg;
	private HashMap<String, Socket> hm;
	InputStream is;
	InputStreamReader isr;
	BufferedReader br;
	
	public ChatServerThread(Socket client, HashMap<String, Socket> hm) {
		this.client = client;
		this.hm = hm;
		try {
			// 클라이언트가 전송해준 메세지를 수신할 객체 필요 
			is = client.getInputStream();
			isr = new InputStreamReader(is, "utf-8");
			br = new BufferedReader(isr);
			id = br.readLine();
			System.out.println("접속한 사용자의 아이디는 "+ id + " 입니다. ");
			toAll("[ " + id + " ] 님이 접속하셨습니다.");
			
			synchronized(this.hm) {
				this.hm.put(id, client);				
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void run() {
		try {

			
			while(true) {
				userMsg = br.readLine(); // 클라이언트 메세지 가져오기 
			
				if(userMsg.equalsIgnoreCase("quit")) {
					System.out.println(id + "님이 접속을 종료했습니다.  ");
					hm.remove(id);
					client.close();
					break;
				} else if(userMsg.contains("/to")) {
					// 귓속말 메소드 // 
				} else {
					toAll("[ " + id + " ] : " + userMsg);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void toAll(String msg) {
		
		Set<Entry<String, Socket>> entry = hm.entrySet();
		
		try {
			for(Entry<String, Socket> e : entry) {
				
				Socket soc = e.getValue();
				// 수신한 메세지를 클라이언트에게 재전송할 객체 필요 
				OutputStream os = soc.getOutputStream();
				OutputStreamWriter osw = new OutputStreamWriter(os);
				pw = new PrintWriter(osw);
				
				pw.println(msg);
				pw.flush();
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
